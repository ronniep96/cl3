import json

def printboard(board):
	for x in board:
		print x

def safe(board,row,column):
	for i in range(8):
		for j in range(8):
			if board[i][j]==1:
				if i==row or j==column:
					return False
				if abs(row-i) == abs(column-j):
					return False
	return True


def solveboard(board,column):
	if column>=8:
		return True

	for i in range (8):
		if safe(board,i,column):
			board[i][column]=1
			if solveboard(board,column+1):
				return True

		board[i][column]=0
	return False



json_data=[]
with open('input.json','r') as json_file:
	json_data=json.load(json_file)

board=[[0 for x in range (8)] for y in range (8)]
board[json_data["start"]][0]=1
print "Initial Configuration is:"
printboard(board)

if (solveboard(board,1)==True):
	print "Board Solved!"
	printboard(board)
else:
	print "Couldn't be solved!"
