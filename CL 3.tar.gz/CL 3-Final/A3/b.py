def d2b(x):
        i=7
        z=[0]*8
        temp=x
        while i>=0:
                z[i]=temp%2
                temp=temp/2
                i-=1
        return z

def add(x,y):
        z=[0]*17
        c=0
        i=16
        while i>=0:
                temp=x[i]+y[i]+c
                z[i]=temp%2
                c=temp/2
                i-=1
        return z

def add1(x,y):
        z=[0]*16
        c=0
        i=15
        while i>=0:
                temp=x[i]+y[i]+c
                z[i]=temp%2
                c=temp/2
                i-=1
        return z

def rightshift(x):
        i=16
        while i>0:
                x[i]=x[i-1]
                i-=1
        return x

def b2d(x):
        result=0
        sign=x[0]
        if x[0]==1:
                i=15
                while i>=0:
                        x[i]=1-x[i]
                        i-=1
                print "inversion:",x
                one = [0]*15 + [1]
                x=add1(x,one)

        p=0
        i=15
        while i>=0:
               if x[i]==1:
                       result=result + 2**p
               p+=1
               i-=1
        if sign==1:
                return -result
        return result

def prod(x,y):
        Q=d2b(x)
        print Q
        M=d2b(y)
        print M
        Minus_M=d2b(-y)
        print Minus_M

        p=[0]*8
        p.extend(Q)
        p.append(0)
        print p

        i=0
        while i<8:
                if (p[-2]==1 and p[-1]==0):
                        Minus_M += [0]*9
                        p=add(p,Minus_M)
                        print "A-M:",p
                elif (p[-2]==0 and p[-1] ==1):
                        M += [0]*9
                        p=add(p,M)
                        print "A+M:",p
                p=rightshift(p)
                print "Rightshifted :",p
                i+=1

        p.pop()
        print p
        result=b2d(p)
        print "Result:",result
        return result
